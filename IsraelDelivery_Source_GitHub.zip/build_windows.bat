@echo off
chcp 65001 >nul
REM דרישות: Godot 4.3+ ו-Export Templates מותקנים. עדכן את הנתיב אם צריך.
set GODOT=godot.exe
if not exist build mkdir build
%GODOT% --headless --path . --export-release "Windows Desktop" build/IsraelDelivery.exe
if errorlevel 1 (echo הבנייה נכשלה & exit /b 1)
echo נוצר: build\IsraelDelivery.exe
echo להפקת מתקין: פתח installer\setup.iss ב-Inno Setup ולחץ Compile.
